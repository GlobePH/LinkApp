<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class LinkAppUser extends Model
{
    protected $table = 'linkapp_users';
}
