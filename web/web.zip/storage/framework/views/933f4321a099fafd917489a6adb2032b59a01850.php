<?php if(isset($dataTypeContent->{$row->field})): ?>
    <br>
    <small>Leave empty to keep the same</small>
<?php endif; ?>
<input type="password" class="form-control" name="<?php echo e($row->field); ?>" value="">